ALTER TABLE wcf1_user_group ADD canBeMessaged TINYINT(1) DEFAULT 0;
ALTER TABLE wcf1_user_group ADD messagingAlias VARCHAR(255);